-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Generation Time: Nov 15, 2019 at 12:06 PM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.11

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `tokomusik`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id_admin` int(11) NOT NULL,
  `email` varchar(120) NOT NULL,
  `username` varchar(64) NOT NULL,
  `password` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id_admin`, `email`, `username`, `password`) VALUES
(1, 'admin@musco.co', 'admin', '21232f297a57a5a743894a0e4a801fc3');

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id_category` int(11) NOT NULL,
  `kategori` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id_category`, `kategori`) VALUES
(1, 'Gitar'),
(2, 'Piano'),
(3, 'Biola'),
(4, 'Akordeon'),
(5, 'Harmonika'),
(6, 'Drum');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` varchar(64) NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `id_category` int(11) NOT NULL,
  `stock` varchar(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `name`, `price`, `image`, `description`, `id_category`, `stock`) VALUES
('5dc4dde5f0d60', 'Piano', 8000000, 'default.jpg', 'Piano impor dari jepang dengan kualitas tinggi. Kondisi baru siap kirim seluruh daerah jawa dan sumatra. spesifikasi tuts yang bagus dan dilengkapi kursi\r\n', 2, '5'),
('5dc4e332180b4', 'Yamaha Gitar Klasik C-40', 900000, '5dc4e332180b4.jpg', '6 String Nylon,body Gloss,Neck Rosewood,Fingerboard Rosewood,Fret 18,5', 1, '24'),
('5dc5172e95a81', 'Gitar Klasik', 200000, '5dc5172e95a81.jpg', 'gitar akustik keadaan baru', 1, '2'),
('5dcd31da610ec', 'Biola Elektrik S-40', 0, '5dcd31da610ec.jpg', 'Biola elektrik warna silver keadaan baru', 0, ''),
('5dcd3523c0604', 'Biola', 9000000, '5dcd3523c0604.jpg', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque vel pretium neque. Ut scelerisque mattis leo ut vulputate. Duis nec.', 3, '4'),
('5dcd3788a7007', 'HOHNER Thunderbird Harmonica', 400000, '5dcd3788a7007.jpg', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Pellentesque vel pretium neque. Ut scelerisque mattis leo ut vulputate. Duis nec.', 4, '40');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` varchar(11) NOT NULL,
  `email` varchar(256) NOT NULL,
  `username` varchar(256) NOT NULL,
  `password` varchar(256) NOT NULL,
  `status` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `email`, `username`, `password`, `status`) VALUES
('USR001', 'krisna@amarta.com', 'krisna', '1bfbc84375d05dc92dc5b2bae463e842', 'aktif'),
('USR002', 'userbaru@email.com', 'user', 'ee11cbb19052e40b07aac0ca060c23ee', 'aktif'),
('USR003', 'tes@email.com', 'tes', '28b662d883b6d76fd96e4ddc5e9ba780', 'aktif');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id_admin`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id_category`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id_admin` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id_category` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
