<?php defined('BASEPATH') OR exit('No direct script access allowed');
 
class Login_model extends CI_Model{	

    private $_table = "admin";
    public $username;
    public $password;

    public function ceklogin(){
        $post = $this->input->post();
		$username = $this->input->post('username');
		$password = $this->input->post('password');
		$where = array(
			'username' => $username,
			'password' => md5($password)
			);

        
        
        return $this->db->get_where($this->_table,$where);
    }

	// function cek_login($table,$where){		
	// 	return $this->db->get_where($table,$where);
	// }	
}