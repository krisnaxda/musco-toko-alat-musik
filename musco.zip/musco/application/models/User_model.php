<?php defined('BASEPATH') OR exit('No direct script access allowed');

class User_model extends CI_Model{
    private $_table = "user";
    public $user_id;
    public $email;
    public $username;
    public $status;

    public function rules(){
        return [
            ['field' => 'email',
            'label' => 'Email',
            'rules' => 'required']
        ];
    }
    

    public function getAll(){
        return $this->db->get($this->_table)->result();
    }

    public function getById($id){
        return $this->db->get_where($this->_table, ["id_category" => $id])->row();
    }

    public function save(){

//         // membaca kode barang terbesar
// $query = "SELECT max(kode_barang) as maxKode FROM tbl_barang";
// $hasil = mysql_query($query);
// $data  = mysql_fetch_array($hasil);
// $kodeBarang = $data['maxKode'];

// // mengambil angka atau bilangan dalam kode anggota terbesar,
// // dengan cara mengambil substring mulai dari karakter ke-1 diambil 6 karakter
// // misal 'BRG001', akan diambil '001'
// // setelah substring bilangan diambil lantas dicasting menjadi integer
// $noUrut = (int) substr($kodeBarang, 3, 3);

// // bilangan yang diambil ini ditambah 1 untuk menentukan nomor urut berikutnya
// $noUrut++;

// // membentuk kode anggota baru
// // perintah sprintf("%03s", $noUrut); digunakan untuk memformat string sebanyak 3 karakter
// // misal sprintf("%03s", 12); maka akan dihasilkan '012'
// // atau misal sprintf("%03s", 1); maka akan dihasilkan string '001'
// $char = "BRG";
// $newID = $char . sprintf("%03s", $noUrut);

        $this->db->select("MAX(user_id) AS maxId");
        $this->db->from($this->_table);
        $query = $this->db->get();
        $hasil = $query->row()->maxId;

        $noUrut = (int) substr($hasil, 3, 3);
        $noUrut++;
        $char = "USR";
        $newID = $char . sprintf("%03s", $noUrut);

        $status = "aktif";

        $post = $this->input->post();
        $this->user_id = $newID;
        $this->email = $post["email"];
        $this->username = $post["username"];
        $this->password = md5($post['password']);
        $this->status = $status;
        $this->db->insert($this->_table, $this);
    }

    public function update(){
        $post = $this->input->post();
        $this->id_category = $post["id"];
        $this->category = $post["category"];
        $this->db->update($this->_table, $this, array('id_category' => $post['id']));
    }

    public function delete($id){
        return $this->db->delete($this->_table, array("id_category" => $id));
    }
}