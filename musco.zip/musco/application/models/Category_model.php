<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Category_model extends CI_Model{
    private $_table = "category";
    public $id_category;
    public $kategori;

    public function rules(){
        return [
            ['field' => 'category',
            'label' => 'Category',
            'rules' => 'required']
        ];
    }
    

    public function getAll(){
        return $this->db->get($this->_table)->result();
    }

    public function getJumlahkat(){

        $select = array(
                        'category.kategori','category.id_category',
                        'count(products.id_category) as total'
                    );

        $this->db->select($select);
        $this->db->from($this->_table);
        $this->db->join('products', 'category.id_category = products.id_category', 'left');
        $this->db->group_by('category.id_category');
        return $this->db->get()->result();
    }
        //     $this->db->select('*');
        // $this->db->from($this->_table);
        // $this->db->join('category', 'category.id_category = products.id_category', 'inner');
        // return $this->db->get()->result();

    public function getById($id){
        return $this->db->get_where($this->_table, ["id_category" => $id])->row();
    }

    public function save(){

        $this->db->select("MAX(id_category)+1 AS id");
        $this->db->from($this->_table);
        $query = $this->db->get();
        $hasil = $query->row()->id;

        // return $query->row()->id; //return salah, koreksi di line 30

        $post = $this->input->post();
        $this->id_category = $hasil;
        $this->kategori = $post["category"];
        $this->db->insert($this->_table, $this);
    }

    public function update(){
        $post = $this->input->post();
        $this->id_category = $post["id"];
        $this->kategori = $post["category"];
        $this->db->update($this->_table, $this, array('id_category' => $post['id']));
    }

    public function delete($id){
        return $this->db->delete($this->_table, array("id_category" => $id));
    }
}