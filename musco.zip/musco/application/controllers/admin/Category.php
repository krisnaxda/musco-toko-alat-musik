<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Category extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        $this->load->model("category_model");
        $this->load->library('form_validation');

        if($this->session->userdata('status') != "admin"){
            echo "<script>alert('Anda harus login dahulu!!');
                    window.location.href='".site_url("admin/login")."';</script>";
        }
    }

    public function index()
    {
        
        $data["category"] = $this->category_model->getJumlahkat();
//        $data["jumlah"] = $this->category_model->getJumlahkat();
        $this->load->view("admin/category/list", $data);
    }

    public function add()
    {
        $category = $this->category_model;
        $validation = $this->form_validation;
        $validation->set_rules($category->rules());

        if ($validation->run()) {
            $category->save();
            $this->session->set_flashdata('success', 'Berhasil disimpan');
        }

        $this->load->view("admin/category/add_new");
    }

    public function edit($id = null)
    {
        if (!isset($id)) redirect('admin/category');
       
        $model = $this->category_model;
        $validation = $this->form_validation;
        $validation->set_rules($model->rules());

        if ($validation->run()) {
            $model->update();
            $this->session->set_flashdata('success', 'Berhasil disimpan');
        }

        $data["category"] = $model->getById($id);
        if (!$data["category"]) show_404();
        
        $this->load->view("admin/category/edit", $data);
    }

    public function delete($id=null)
    {
        if (!isset($id)) show_404();
        
        if ($this->category_model->delete($id)) {
            redirect(site_url('admin/category'));
        }
    }
}