<?php

class Overview extends CI_Controller {
    public function __construct()
    {
        parent::__construct();
    }
    public function index()
    {
        if($this->session->userdata('status') != "admin"){
			echo "<script>alert('Anda harus login dahulu!!');
    				window.location.href='".site_url("admin/login")."';</script>";
        }
        
        $this->load->view("admin/overview.php");
    }
}